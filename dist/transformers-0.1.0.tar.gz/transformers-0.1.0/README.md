# Custom Transformer

This project defines a couple of sklearn custom transformers for further use in other projects.

The project generates its own package and uploads it to Github with every push to main.